package me.dio.bradesco;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BradescoApplication {

	public static void main(String[] args) {
		SpringApplication.run(BradescoApplication.class, args);
	}

}
